export class Roles {
    static admin = 'admin';
    static student = 'student';
}